import joblib
import os
import json
import math
import re
import pandas as pd
from urllib.parse import urlparse
from collections import Counter


# =========================
# Feature Helpers
# =========================
def calculate_entropy(text):
    if len(text) == 0:
        return 0
    probs = [count / len(text) for count in Counter(text).values()]
    return -sum(p * math.log2(p) for p in probs)


SHORTENING_SERVICES = [
    "bit.ly", "tinyurl.com", "t.co",
    "goo.gl", "is.gd", "ow.ly"
]


# =========================
# Feature Extraction
# =========================
def extract_features(url):
    features = {}

    features['url_length'] = min(len(url),100)
    features['dot_count'] = url.count('.')
    features['dash_count'] = url.count('-')
    features['underscore_count'] = url.count('_')
    features['slash_count'] = url.count('/')
    features['question_count'] = url.count('?')
    features['equal_count'] = url.count('=')
    features['ampersand_count'] = url.count('&')

    features['digit_count'] = sum(c.isdigit() for c in url)
    features['upper_count'] = sum(c.isupper() for c in url)
    features['lower_count'] = sum(c.islower() for c in url)

    features['has_https'] = 1 if url.startswith('https://') else 0
    features['has_http'] = 1 if url.startswith('http://') else 0
    features['has_www'] = 1 if 'www.' in url else 0

    ip_pattern = r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'
    features['has_ip'] = 1 if re.search(ip_pattern, url) else 0

    suspicious_words = [
        'click', 'download', 'free', 'win', 'prize',
        'offer', 'limited', 'urgent', 'verify', 'login'
    ]
    features['suspicious_words'] = sum(
        1 for word in suspicious_words if word in url.lower()
    )

    try:
        parsed = urlparse(url)
        features['domain_length'] = len(parsed.netloc)
        path_parts = parsed.path.split('/')
        features['path_depth'] = len([p for p in path_parts if p])
    except:
        features['domain_length'] = 0
        features['path_depth'] = 0

    features['entropy'] = calculate_entropy(url)
    features['is_shortened'] = 1 if any(
        s in url.lower() for s in SHORTENING_SERVICES
    ) else 0

    return features


# =========================
# Load Model + Info
# =========================
def load_model():
    model_path = os.path.join("models", "model.joblib")
    if not os.path.exists(model_path):
        raise FileNotFoundError("model.joblib غير موجود")
    return joblib.load(model_path)


def load_model_info():
    info_path = os.path.join("models", "model_info.json")
    if not os.path.exists(info_path):
        return None
    with open(info_path, 'r', encoding='utf-8') as f:
        return json.load(f)


model = load_model()
model_info = load_model_info()


# =========================
# Prediction
# =========================
def predict_url(url):
    try:
        if not url or not isinstance(url, str):
            raise ValueError("الرابط غير صحيح")

        features = extract_features(url)

        feature_names = model_info['feature_names']
        domain = urlparse(url).netloc.lower()

        trusted_keywords = [
          '.edu',
         '.edu.sa',
         '.ac.',
         'blackboard',
         'lms'
        ]

        suspicious_keywords = [
         'login', 'verify', 'secure',
         'update', 'reset', 'gift',
         'free', 'bonus', 'claim'
        ]

        is_educational = (
    '.edu' in domain
    or '.edu.sa' in domain
    or '.ac.' in domain
    or 'uoh.edu.sa' in domain
    or 'blackboard' in domain
    or 'lms' in domain
)
        is_https = url.startswith('https')
        has_suspicious = any(k in url.lower() for k in suspicious_keywords)

        if (
            is_educational
            and is_https
        ):
            return {
               'label': 'safe',
               'confidence': 0.90,
               'probabilities': {
                   'safe': 0.90,
                  'malicious': 0.10
                 }
    }
         
        #  (مهم جدًا)
        X = pd.DataFrame(
            [[features.get(name, 0) for name in feature_names]],
            columns=feature_names
        )

        prediction = model.predict(X)[0]
        probabilities = model.predict_proba(X)[0]

        label_map = {
            0: 'safe',
            1: 'malicious'
        }
        print("FEATURE NAMES FROM MODEL:", model_info['feature_names'])
        print("INPUT FEATURES:", list(features.keys()))
        return {
            'label': label_map.get(prediction, 'unknown'),
            'confidence': float(max(probabilities)),
            'probabilities': {
                'safe': float(probabilities[0]),
                'malicious': float(probabilities[1])
            }
        }

    except Exception as e:
        return {
            'label': 'error',
            'confidence': 0.0,
            'error': str(e)
        }


# =========================
# Test
# =========================
if __name__ == "__main__":
    test_urls = [
        "https://www.google.com",
        "https://fake-bank.com/login"
    ]

    for url in test_urls:
        result = predict_url(url)
        print(url)
        print(result)
        print("-" * 40)